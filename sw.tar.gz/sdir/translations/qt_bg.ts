<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bg">
<dependencies>
<dependency catalog="qtbase_bg"/>
<dependency catalog="qtscript_bg"/>
<dependency catalog="qtmultimedia_bg"/>
<dependency catalog="qtxmlpatterns_bg"/>
</dependencies>
</TS>
